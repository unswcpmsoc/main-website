# These lines reads the input.
A1, B1, C1, D1 = map(int, input().split())
A2, B2, C2, D2 = map(int, input().split())

# TODO: compute the answer!
answer = -1

# This line outputs the answer.
print(answer)