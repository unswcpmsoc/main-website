#include <stdio.h>

int main() {
    // These lines read the input.
    int A, B;
    scanf("%d%d", &A, &B);

    // TODO: compute the answer!
    int answer = -1;

    // This line outputs the answer.
    printf("%d\n", answer);
}