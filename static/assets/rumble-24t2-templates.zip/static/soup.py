# These lines reads the input.
N1, A1, B1 = map(int, input().split())
tastiness1 = list(map(int, input().split()))
N2, A2, B2 = map(int, input().split())
tastiness2 = list(map(int, input().split()))
N3, A3, B3 = map(int, input().split())
tastiness3 = list(map(int, input().split()))
N4, A4, B4 = map(int, input().split())
tastiness4 = list(map(int, input().split()))
K = int(input())

# For example, sum_of_first stores the sum of the tastiness values of the first carrot of each type.
sum_of_first = tastiness1[0] + tastiness2[0] + tastiness3[0] + tastiness4[0]

# TODO: compute the answer!
answer = -1

# This line outputs the answer.
print(answer)