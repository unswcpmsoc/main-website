#include <stdio.h>

const int MAX_N = 1000, MAX_M = 1000;

int main() {
    // These lines read the input.
    int N, M, heights[MAX_N][MAX_M];
    scanf("%d%d", &N, &M);
    for (int i = 0; i < N; i++) {
        for (int j = 0; j < M; j++) {
            scanf("%d", &heights[i][j]);
        }
    }

    // For example, sum_corners stores the top left height plus the bottom right height.
    int sum_corners = heights[0][0] + heights[N-1][N-1];

    // TODO: print the answer!
    printf("MAYBE");
}