# These lines reads the input.
N = int(input())
elevations = list(map(int, input().split()))

# For example, sum_ends stores the leftmost elevation plus the rightmost elevation.
sum_ends = elevations[0] + elevations[N-1]

# TODO: compute the answer!
answer = -1

# This line outputs the answer.
print(answer)