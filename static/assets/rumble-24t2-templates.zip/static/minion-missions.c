#include <stdio.h>

int main() {
    // These lines read the input.
    int A1, B1, C1, D1, A2, B2, C2, D2;
    scanf("%d%d%d%d", &A1, &B1, &C1, &D1);
    scanf("%d%d%d%d", &A2, &B2, &C2, &D2);

    // TODO: compute the answer!
    int answer = -1;

    // This line outputs the answer.
    printf("%d\n", answer);
}