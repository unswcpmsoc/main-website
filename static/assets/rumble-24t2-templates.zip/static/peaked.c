#include <stdio.h>

const int MAX_N = 100000;

int main() {
    // These lines read the input.
    int N, elevations[MAX_N];
    scanf("%d", &N);
    for (int i = 0; i < N; i++) {
        scanf("%d", &elevations[i]);
    }

    // For example, sum_ends stores the leftmost elevation plus the rightmost elevation.
    int sum_ends = elevations[0] + elevations[N-1];

    // TODO: compute the answer!
    int answer = -1;

    // This line outputs the answer.
    printf("%d\n", answer);
}