/**
 * Binary search over the answer (length required so that any window has maximal number of unique values)
 * For each length, check in O(n) using sliding window which maintains frequencies and `numUnique`
 * I used a struct for clarity, you may chose to do it without a struct in contest
 * 
 * Takeaways:
 *  - ask yourself "how can a program verify an answer quickly"
 *  - A binary search is always motivated by observing a monotonic property (often binary searching for the answer)
 *  - go through algos/techniques you know and see which is applicable
 */

#include <bits/stdc++.h>
using namespace std;


int N, A[200005];
unordered_set<int> setA;

struct UniqueWindow {
    int numUnique = 0;
    unordered_map<int, int> freq;
    void add(int val) {
        if (freq[val] == 0) numUnique++;
        freq[val]++;
    }

    void remove(int val) {
        freq[val]--;
        if (freq[val] == 0) numUnique--;
    }
};

bool good(int len) {
    UniqueWindow slidingWindow;
    for (int i = 0; i < len; ++i) slidingWindow.add(A[i]);
    for (int i = len; i < N; ++i) {
        if (slidingWindow.numUnique < setA.size()) {
            return false;
        }
        slidingWindow.remove(A[i - len]);
        slidingWindow.add(A[i]);
    }
    if (slidingWindow.numUnique < setA.size()) {
        return false;
    }
    return true;
}

int main() {
    cin.tie(0); ios::sync_with_stdio(0);
    cin >> N;
    for (int i = 0; i < N; ++i) {
        cin >> A[i];
        setA.insert(A[i]);
    }

    int l = 1, r = N;
    while (l < r) {
        int m = (l + r) / 2;
        if (good(m)) r = m;
        else l = m + 1;
    }
    cout << l << "\n";
}