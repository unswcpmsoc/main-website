/**
 * Non integers are annoying, convert to integers (thankfully denominators are small)
 * dp where dp[value] = minimum number of coins to achieve this exact value
 * base case is dp[0] = 0, because it takes at least 0 coins to get $0
 * note that order of computation is by increasing `currVal`, because we can take any amount of a particular type of coin
 * 
 * Takeaways:
 *  - do `n * MUL / d` instead of `n / d * MUL` due to order of operations
 *  - rephase question as "minimum number of items to achieve value", to inspire a knapsack dp
 *  - make `tmax` or `tmin` functions for dp questions - EXTREMELY USEFUL!
 */

#include <bits/stdc++.h>
using namespace std;
constexpr int MUL = 2520; // gcd(1..10)

int N, C;
int dp[150000];

// update variable to the best of its current value and a new value
template<typename T> void tmin(T &a, T b) {
    if (b < a) a = b;
}

int main() {
    fill(begin(dp), end(dp), INT_MAX);
    dp[0] = 0;
    
    cin.tie(0); ios::sync_with_stdio(0);
    cin >> N >> C;
    N *= MUL;

    for (int n, d, i = 0; i < C; ++i) {
        cin >> n >> d;
        int newVal = n * MUL / d;
        for (int currVal = 0; currVal + newVal < 150000; ++currVal) {
            if (dp[currVal] != INT_MAX) {
                tmin(dp[currVal + newVal], dp[currVal] + 1);
            }
        }
    }

    if (dp[N] == INT_MAX) {
        cout << -1 << "\n";
    } else {
        cout << dp[N] << "\n";
    }
}