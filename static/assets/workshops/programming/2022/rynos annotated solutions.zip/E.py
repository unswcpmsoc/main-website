"""
Just implement it.
Note that I sorted based on `(sum, a)` instead of `(average, a)`. I'm kinda lazy oop
The problem statement is unclear - I'm assuming there cant be any ties after considering `sum` and `a`

Takeaways:
 - Sort items of data by storing them as a pair of `(criteria we are sorting for, other useful information)`
 - e.g. i implemented dijkstra priority_queue as a pair of `{dist, node id}`
"""
P = int(input())

problems = []
for _ in range(P):
    s, a, b, c = input().split()
    score = int(a) + int(b) + int(c)
    problems.append(((score, int(a)), s))

print(min(problems)[1])
