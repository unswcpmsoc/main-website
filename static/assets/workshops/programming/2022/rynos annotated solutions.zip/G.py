"""
Lmao!!!! I can't believe this is actually the solution

Alternative solution: instead of move*3, map moves to their inverse moves
Maximum number of moves will now be 50

Takeaways:
 - dont overthink things
"""

moves = input()
for move in moves[::-1]:
    print(move*3, end="")
