/**
 * Reverse order of queries and updates, so that we support:
 *  - join 2 components
 *  - check if 2 nodes belong to the same component
 * => disjoint set union
 * 
 * Note that we are garunteed x < y (if this is not the case we need to swap(x, y) when necessary so that we only look at unique pairs)
 * 
 * Takeaways:
 *  - Often questions that involve only queries & remove updates are annoying, reverse order (e.g. AIIO 2022 purview)
 *  - think about how to reverse queries and execute them in reverse order - this may get messy quickly
 */

#include <bits/stdc++.h>
using namespace std;

struct Query {
    char type;
    int x, y;
};

int N, F, Q;
int parent[100005];
set<pair<int, int>> edges;
vector<Query> queries;
vector<bool> answers;

int getParent(int node) {
    if (parent[node] == node) return node;
    return parent[node] = getParent(parent[node]);
}

int main() {
    cin.tie(0); ios::sync_with_stdio(0);
    cin >> N >> F >> Q;
    for (int i = 1; i <= N; ++i) parent[i] = i;
    for (int x, y, i = 0; i < F; ++i) {
        cin >> x >> y;
        edges.insert({x, y});
    }
    for (int x, y, i = 0; i < Q; ++i) {
        char type;
        cin >> type >> x >> y;
        queries.push_back({type, x, y});
        if (type == 'E') {
            edges.erase({x, y});
        }
    }

    for (pair<int, int> edge : edges) {
        parent[getParent(edge.first)] = getParent(edge.second);
    }

    reverse(queries.begin(), queries.end());
    for (Query q : queries) {
        if (q.type == 'E') {
            parent[getParent(q.x)] = getParent(q.y);
        } else {
            answers.push_back(getParent(q.x) == getParent(q.y));
        }
    }

    reverse(answers.begin(), answers.end());
    for (bool answer : answers) {
        cout << (answer ? "YES" : "NO") << "\n";
    }
}