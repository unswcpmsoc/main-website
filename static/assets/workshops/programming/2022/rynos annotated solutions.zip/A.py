"""
We are given the requirements of a valid date - might as well make that a function
Note that 6! is small, try all options naively

Takeaways:
 - in cases like these, hardcoded constants are better as maps than as arrays
 - perhaps do things for completeness even if unnecessary (e.g. year = 2000 + year)
 - `intertools.permutations` is  nice, c++ has an equivalent called `next_permutation`
"""

from itertools import *

DAYS = {
    1: 31,
    2: 28,
    3: 31,
    4: 30,
    5: 31,
    6: 30,
    7: 31,
    8: 31,
    9: 30,
    10: 31,
    11: 30,
    12: 31
}

def possible(day, month, year):
    year = 2000 + year

    # leap year
    if year % 4 == 0 and month == 2 and day == 29:
        return True
    return 1 <= month <= 12 and 1 <= day <= DAYS[month]

T = int(input())
dates = []
for _ in range(T):
    a, b, c = map(int, input().split("/"))
    dates.append((a, b, c))

validFormats = []

for perm in permutations(("DD", "MM", "YY")):
    if all(
        possible(date[perm.index("DD")], date[perm.index("MM")], date[perm.index("YY")])
        for date in dates
    ):
        validFormats.append("/".join(perm))

if len(validFormats) > 1:
    print("UNSURE")
elif len(validFormats) == 1:
    print(*validFormats)
else:
    print("IMPOSSIBLE")