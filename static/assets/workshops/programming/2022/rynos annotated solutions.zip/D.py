"""
(sum of A_i * "number of ranges that contains index i") / (Total number of ranges)

Alternative solution is to calculate prefix sum (motivation is because we want to do range sums quickly)
Then calculate prefix prefix sum to optimise to O(n)

Takeaways:
 - the average is the sum of the values and the number of values, calculating both individually is simpler
 - reframe your perspective - this is often the case for most questions, especially combinatorics/counting things
"""

from math import gcd

N = int(input())
numerator = 0
denominator = N * (N + 1) // 2

for i, a in enumerate(map(int, input().split())):
    numerator += a * (N - i) * (i + 1)

g = gcd(numerator, denominator)
numerator //= g
denominator //= g
print(f"{numerator}/{denominator}")
