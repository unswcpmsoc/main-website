"""
Just an implementation question
Optimisation would be to store a prefix of letter frequencies

Takeaways:
 - Always do time complexity analysis before you start coding (Im suprised this didnt time out lol)
"""

S = input().split()
W = int(input())

"""A and B are anagrams iff they are different but contain the same characters"""
def isAnagrams(A, B):
    return A != B and sorted(A) == sorted(B)

def hasMatches(w):
    # iterate over substrings of S
    for r in range(len(S) + 1):
        for l in range(r):
            if isAnagrams("".join(S[l:r]), w):
                return True
    return False

for _ in range(W):
    w = input()
    if hasMatches(w):
        print(w)

