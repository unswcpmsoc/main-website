"""
Just implementation
Note that ceil(a / b) is more commonly written as (a + b - 1) // b, where // means floordiv
I chose this option for clarity

Takeaways:
 - justify why we use ceildiv rather than floodiv
"""
import math

M, N = map(int, input().split())
lengths = [int(input()) for _ in range(M)]
print(math.ceil(sum(lengths) / N))
