"""
AHHHHH i hate comp geom
f(theta) = side length required if triangle is rotated by theta
i binary search over `f` to find minima
but the function is not monotonic, so i split it into smaller regions which i hope are monotonic
whoops, how did this even work

Alternative solution is to start with some evenly distributed angles
Iteratively twiggle them and keep the best few, until twiggle side is below some threshold
genetic algorithm vibes

Alternative solution is any way that you can gradient descent to find the minima of an unknown function
Btw a purely maths solution doesnt work because the equations are too yucky

Takeaways:
 - join Dallas' team and let him deal with the comp geom questions
"""
import math

A, B, C = map(int, input().split())
diff = math.acos((B**2 + C**2 - A**2) / (2 * B * C))

"""
a triangle is defined by 3 points
WLOG let (0, 0) be one of the points
(0, 0) is connected with the side of length B to B*cis(theta)
(0, 0) is connected with the side of length C to C*cis(theta + diff), where
diff is the angle between sides B and C
then the bounding square is either the difference between the min and max X
coordinates, or the difference between the min and max Y coordinates
"""
def f(theta):
    Ccos = math.cos(theta)
    Csin = math.sin(theta)
    Bcos = math.cos(theta + diff)
    Bsin = math.sin(theta + diff)
    
    minX = min(0, C * Ccos, B * Bcos)
    maxX = max(0, C * Ccos, B * Bcos)
    minY = min(0, C * Csin, B * Bsin)
    maxY = max(0, C * Csin, B * Bsin)
    
    return max(maxX - minX, maxY - minY)

DO_BIN_SEARCH_SOL = True
if DO_BIN_SEARCH_SOL:
    best = float("inf")
    for l, r in [(0, 0.5), (0.5, 1), (1, 1.5), (1.5, 2), (2, 2.5), (2.5, 3), (3, math.pi)]:
        while r - l > 1e-15:
            m = (l + r) / 2
            if f(m) > f(m + 1e-9):
                l = m
            else:
                r = m
        best = min(best, f(l), f(r))
    print(best)
else:
    N_SAMPLES = 100

    def filterBest(points):
        points = [(f(x), x) for x in points]
        bestPoints = sorted(points)[:N_SAMPLES]
        return [x for y, x in bestPoints]

    points = [(n / N_SAMPLES) * math.pi for n in range(N_SAMPLES + 1)]
    twiggle = 1 / N_SAMPLES
    while twiggle > 1e-18:
        points = filterBest(points)
        points = [x + twiggle for x in points] + [x - twiggle for x in points]
        twiggle *= 0.8
    print(f(points[0]))
