/**
 * bfs from S
 * obstacles are horizontal and vertical boundaries of rectangles, maintained in `rows[]` and `cols[]` segtrees
 * after bfs, find cells that are reachable by the bfs and not contained in any rectangles
 * 
 * Takeaways:
 *  - annoying 2D questions are often segtree sweeplines or some variant
 *  - work things out on paper! this helps especially for off by 1 errors
 *  - we familiar with a segtree implementation and segtree variants
 */

#include <bits/stdc++.h>
using namespace std;

constexpr int dx[] = {1, 0, 0, -1, 1, 1, -1, -1};
constexpr int dy[] = {0, 1, -1, 0, 1, -1, 1, -1};

struct Segtree {
    int size;
    vector<int> t;

    Segtree(int size_): size(size_) {
        t = vector<int>(size * 4, 0);
    }

    void add(int tl, int tr, int val, int node = 1, int l = 1, int r = INT_MAX) {
        r = min(r, size);
        if (tl > r || l > tr) return;
        if (tl <= l && r <= tr) {
            t[node] += val;
            return;
        }

        int m = (l + r) / 2;
        add(tl, min(m, tr), val, node * 2, l, m);
        add(max(m + 1, tl), tr, val, node * 2 + 1, m + 1, r);
    }

    int query(int index, int node = 1, int l = 1, int r = INT_MAX) {
        r = min(r, size);
        if (l == r) return t[node];
        int m = (l + r) / 2;
        if (index <= m) return t[node] + query(index, node * 2, l, m);
        else return t[node] + query(index, node * 2 + 1, m + 1, r);
    }
};

struct Update {
    int r, c1, c2, val;
    bool operator<(Update o) const {
        return r < o.r;
    }
};

int R, C, K;
Segtree *rows[100005], *cols[100005];
vector<bool> seen[100005];
queue<pair<int, int>> q, newQ;
vector<Update> updates;

bool isValid(int r, int c) {
    return 1 <= r && r <= R && 1 <= c && c <= C;
}

bool isSafe(int r, int c) {
    return rows[r]->query(c) == 0 && cols[c]->query(r) == 0;
}

void push() {
    while (!q.empty()) {
        pair<int, int> pos = q.front();
        q.pop();
        if (!isSafe(pos.first, pos.second)) continue;

        for (int dirI = 0; dirI < 8; ++dirI) {
            int newR = pos.first + dx[dirI];
            int newC = pos.second + dy[dirI];
            if (isValid(newR, newC) && !seen[newR][newC] && isSafe(newR, newC)) {
                newQ.push({newR, newC});
                seen[newR][newC] = true;
            }
        }
    }
    swap(q, newQ);
}

void update(int r1, int c1, int r2, int c2) {
    updates.push_back({r1,     c1, c2, 1});
    updates.push_back({r2 + 1, c1, c2, -1});
    rows[r1]->add(c1, c2, 1);
    rows[r2]->add(c1, c2, 1);
    cols[c1]->add(r1, r2, 1);
    cols[c2]->add(r1, r2, 1);
}

void reportAns() {
    sort(updates.begin(), updates.end());
    Segtree sweepline(C + 1);
    
    int updateI = 0;
    for (int r = 1; r <= R; ++r) {
        while (updateI < updates.size() && updates[updateI].r == r) {
            sweepline.add(updates[updateI].c1, updates[updateI].c2, updates[updateI].val);
            updateI++;
        }
        
        for (int c = 1; c <= C; ++c) {
            if (seen[r][c] && sweepline.query(c) == 0) {
                cout << r << " " << c << "\n";
                return;
            }
        }
    }

    cout << -1 << "\n";
    return;
}


int main() {
    cin.tie(0); ios::sync_with_stdio(0);
    cin >> R >> C >> K;
    for (int r = 1; r <= R; ++r) rows[r] = new Segtree(C + 1);
    for (int c = 1; c <= C; ++c) cols[c] = new Segtree(R + 1);
    for (int r = 1; r <= R; ++r) seen[r] = vector<bool>(C + 1, false);

    for (int r = 1; r <= R; ++r) {
        for (int c = 1; c <= C; ++c) {
            char cell;
            cin >> cell;
            if (cell == 'X') {
                update(r, c, r, c);
            } else if (cell == 'S') {
                q.push({r, c});
                seen[r][c] = true;
            }
        }
    }
    
    for (int i = 1; i <= K; ++i) {
        push();
        int r1, c1, r2, c2;
        cin >> r1 >> c1 >> r2 >> c2;
        update(r1, c1, r2, c2);
    }
    
    reportAns();
}