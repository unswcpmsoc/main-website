/**
 * construct graphs to represent possible pathways and legal pathways
 * dfs to find "reachable" nodes from start node
 * 
 * You may chose to make a generic dfs function that additionally takes a vector array by reference and a boolean array by reference
 * You may chose to use a bfs instead, but a dfs is way quicker to write
 * 
 * Takeaways:
 *  - variable naming is important! and it makes things so much easier to debug, since the code becomes really readable
 *  - for example the last few lines make sense
 *  - we are finding "whether is it legal" and "whether is it possible". its best to answer these questions seperately because they are independant
 *  - how would you do this question by hand? then formalise into an algo
 *  - rule of thumb: always chose dfs over bfs when possible
 */

#include <bits/stdc++.h>
using namespace std;

int N, X, Y;
vector<int> possibleRoutes[1005], legalRoutes[1005];
bool possible[1005], legal[1005];


void dfsPossible(int node) {
    if (possible[node]) return;
    possible[node] = true;
    for (int child : possibleRoutes[node]) {
        dfsPossible(child);
    }
}

void dfsLegal(int node) {
    if (legal[node]) return;
    legal[node] = true;
    for (int child : legalRoutes[node]) {
        dfsLegal(child);
    }
}

int main() {
    cin.tie(0); ios::sync_with_stdio(0);
    cin >> N >> X >> Y;
    for (int u, v, i = 0; i < X; ++i) {
        cin >> u >> v;
        possibleRoutes[u].push_back(v);
        possibleRoutes[v].push_back(u);
        legalRoutes[u].push_back(v);
        legalRoutes[v].push_back(u);
    }
    for (int u, v, i = 0; i < Y; ++i) {
        cin >> u >> v;
        possibleRoutes[u].push_back(v);
        possibleRoutes[v].push_back(u);
        legalRoutes[u].push_back(v);
    }

    dfsPossible(1);
    dfsLegal(1);

    for (int i = 1; i <= N; ++i) {
        if (!possible[i]) cout << "Impossible\n";
        else if (!legal[i]) cout << "Ticket\n";
        else cout << "No Ticket\n";
    }
}