N, W = map(int, input().split())
if W == 2:
    print((N * 2) - (N % 2))
elif W == 3:
    print((N * 4 // 3) - (N % 6 == 3))
else:
    print("Invalid input")