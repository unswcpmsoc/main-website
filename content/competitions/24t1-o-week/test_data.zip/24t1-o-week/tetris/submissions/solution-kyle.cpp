#include <bits/stdc++.h>

using namespace std;

int main() {
    int N, W; scanf("%d%d", &N, &W);

    if (W == 2) {
        cout << (N / 2) * 4 + (N % 2);
    } else {
        cout << floor(N * 4 / 3.0) - (N % 6 == 3);
    }

    return 0;
}