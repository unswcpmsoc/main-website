// do simple bfs as input is 2-colourable graph

#include <iostream>
#include <queue>

using namespace std;

vector<int> adj[100005];
int dist[100005];

int main() {
    int n, m; cin >> n >> m;
    int st, en; cin >> st >> en;

    for (int i = 0; i < m; i++) {
        int a, b, col; cin >> a >> b >> col;
        adj[a].push_back(b);
    }

    fill(&dist[0], &dist[0] + sizeof(dist) / sizeof(dist[0]), 1e9);

    queue<int> q;

    q.push(st);
    dist[st] = 0;

    while (!q.empty()) {
        auto node = q.front();
        q.pop();

        for (auto nxt : adj[node]) {
            if (dist[nxt] > dist[node] + 1) {
                dist[nxt] = dist[node] + 1;
                q.push(nxt);
            }
        }
      
    }
    
    if (dist[en] == 1e9) cout << "IMPOSSIBLE";
    else cout << max(0, dist[en] - 1);
}