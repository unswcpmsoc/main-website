#include <iostream>
#include <deque>
#include <queue>
#include <map>

using namespace std;

vector<pair<int, int>> adj[100005];
map<int, int> dist[100005];

struct state {
  int node, col, cost;

  bool operator<(state o) const {
    return cost > o.cost;
  }
};

int main() {
  int n, m; cin >> n >> m;
  int st, en; cin >> st >> en;

  for (int i = 0; i < m; i++) {
    int a, b, col; cin >> a >> b >> col;

    adj[a].push_back({b, col});
  }

  priority_queue<state> pq;

  for (auto nxt : adj[st]) {
    pq.push({nxt.first, nxt.second, 0});
    dist[nxt.first][nxt.second] = 0;
  }

  while (!pq.empty()) {
    auto [node, col, cost] = pq.top();
    pq.pop();

    if (cost != dist[node][col]) continue;

    for (auto [dnode, dcol] : adj[node]) {
      if (col == dcol) {
        if (dist[dnode].count(dcol) == 0 || dist[dnode][dcol] > dist[node][col]) {
          dist[dnode][dcol] = dist[node][col];
          pq.push({dnode, dcol, dist[dnode][dcol]});
        }
      } else {
        if (dist[dnode].count(dcol) == 0 || dist[dnode][dcol] > dist[node][col] + 1) {
          dist[dnode][dcol] = dist[node][col] + 1;
          pq.push({dnode, dcol, dist[dnode][dcol]});
        }
      }
    }
  }

  int ans = 1e9;

  for (auto [idx, val] : dist[en]) {
    ans = min(ans, val);
  }

  if (ans == 1e9) cout << "IMPOSSIBLE";
  else cout << ans;
}