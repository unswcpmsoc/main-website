// ryno

#include <bits/stdc++.h>
#include <cassert>
using namespace std;
typedef long long ll;

ll N;
ll arr[1000005];

ll getSum(ll m) {
    ll total = 0;
    for (ll i = 0; i < N; ++i) {
        total += arr[i] % m;
    }
    return total;
}

signed main() {
    cin >> N;
    assert(N <= 100000);
    for (ll i = 0; i < N; ++i) {
        cin >> arr[i];
        assert(0 <= arr[i] && arr[i] <= 1000);
    }

    ll best = LLONG_MAX;
    for (ll m = 2; m <= 100000; ++m) {
        // cout << m << " " << getSum(m) << "\n";
        best = min(best, getSum(m));
    }
    cout << best << "\n";
}