// ryno

#include <bits/stdc++.h>
#include <cassert>
using namespace std;
typedef long long ll;

ll N;
ll arr[100005];
ll lastM[100005];

signed main() {
    cin >> N;
    for (int i = 0; i < N; ++i) {
        cin >> arr[i];
    }
    sort(arr, arr + N, greater<int>());

    map<ll, vector<int>> checkpoints;
    for (int i = 0; i < N; ++i) {
        if (arr[i] == 0) {
            checkpoints[2].push_back(i);
        }
        for (ll x = 1; (x - 1) * (x - 1) <= arr[i]; ++x) {
            checkpoints[x].push_back(i);
            checkpoints[arr[i] / x + 1].push_back(i);
        }
    }
    for (ll x = 1; (x - 1) * (x - 1) <= arr[N-1]; ++x) {
        checkpoints[x].push_back(N-1);
    }

    pair<ll, ll> ans = {LLONG_MAX, -1};
    const ll sum = accumulate(arr, arr + N, 0ll);
    ll sumDiv = 0;
    for (auto [m, todoI] : checkpoints) {
        if (m - 1 > 1) {
            ans = min(ans, {sum - sumDiv * (m - 1), m-1});
        }
        for (ll i : todoI) {
            if (lastM[i] == m) continue;
            lastM[i] = m;
            sumDiv += (arr[i] / m) - ((m-1) == 0 ? 0 : arr[i] / (m-1));
        }
        if (m > 1) {
            ans = min(ans, {sum - sumDiv * m, m});
        }
    }

    // cout << ans.second << "\n";

    cout << ans.first << "\n";
}
