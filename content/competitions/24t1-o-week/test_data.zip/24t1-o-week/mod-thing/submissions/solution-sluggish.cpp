// ryno

#include <bits/stdc++.h>
#include <cassert>
using namespace std;
typedef long long ll;

ll N;
ll arr[100005];

// ll getSum(ll m) {
//     ll total = 0;
//     for (ll i = 0; i < N; ++i) {
//         total += arr[i] % m;
//     }
//     return total;
// }

// return smallest values of m such that floor(a / m) is unique
// tested equivalent to
//     set<ll> seen;
//     vector<ll> C;
//     for (ll i = 1; i <= x; ++i) {
//         if (!seen.count(x / i)) {
//             seen.insert(x / i);
//             C.push_back(i);
//         }
//     }
//     return C;
set<ll> getCheckpoints(ll a) {
    vector<ll> checkpoints;
    if (a <= 1) {
        checkpoints.push_back(1);
        checkpoints.push_back(2); 
    } else {
        for (ll i = 1; (i - 1) * (i - 1) <= a; ++i) {
            checkpoints.push_back(i);
            checkpoints.push_back(a / i + 1);
            checkpoints.push_back(a / i);
        }
    }
    return set<ll>(checkpoints.begin(), checkpoints.end());
}


signed main() {
    cin >> N;
    assert(N <= 100'000);
    for (int i = 0; i < N; ++i) {
        cin >> arr[i];
        assert(0 <= arr[i] && arr[i] <= 100'000);
    }

    map<ll, vector<int>> checkpoints;
    for (int i = 0; i < N; ++i) {
        for (ll checkpoint : getCheckpoints(arr[i])) {
            checkpoints[checkpoint].push_back(i);
        }
    }

    ll ans = LLONG_MAX;
    const ll sum = accumulate(arr, arr + N, 0ll);
    ll prevM = 0;
    ll sumDiv = 0;
    for (auto [m, todoI] : checkpoints) {
        for (ll i : todoI) {
            sumDiv += (arr[i] / m) - (prevM == 0 ? 0 : arr[i] / prevM);
        }
        // assert(sumDiv * m <= sum);

        // cout << m << " " << sum - sumDiv * m << "\n";
        if (m > 1) {
            ll sumMod = sum - sumDiv * m;
            // assert(getSum(m) == sumMod);
            ans = min(ans, sumMod);
        }
        prevM = m;
    }
    
    assert(prevM > 1);
    assert(ans != LLONG_MAX);

    cout << ans << "\n";
}
