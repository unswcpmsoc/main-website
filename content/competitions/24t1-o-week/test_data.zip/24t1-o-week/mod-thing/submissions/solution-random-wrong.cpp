// ryno - random

#include <bits/stdc++.h>
#include <cassert>
using namespace std;
typedef long long ll;

ll N;
ll arr[1005];

ll getSum(ll m) {
    ll total = 0;
    for (ll i = 0; i < N; ++i) {
        total += arr[i] % m;
    }
    return total;
}

vector<ll> factorise(ll x) {
    vector<ll> primes;
    ll d = 2;
    while (x > 1) {
        if (x % d == 0) {
            primes.push_back(d);
            while (x % d == 0) x /= d;
        }
        d++;
    }
    return primes;
}

signed main() {
    cin >> N;
    assert(N <= 1000);
    for (ll i = 0; i < N; ++i) {
        cin >> arr[i];
        assert(0 <= arr[i] && arr[i] <= 1000);
    }

    ll best = LLONG_MAX;
    for (ll rep = 0; rep < 10; ++rep) {
        ll i = rand() % N;
        auto factors = factorise(arr[i]);
        for (auto p : factors) {
            best = min(best, getSum(p));
        }
    }
    cout << best << "\n";
}