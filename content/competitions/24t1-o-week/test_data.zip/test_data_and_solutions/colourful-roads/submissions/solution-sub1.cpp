// check if same connected component as all roads are same colour

#include <iostream>
#include <deque>

using namespace std;

vector<int> adj[100005];
bool seen[100005];

void dfs(int node) {
    for (auto nxt : adj[node]) {
        if (seen[nxt]) continue;
        seen[nxt] = true;
        dfs(nxt);
    }
}

int main() {
    
    int n, m; cin >> n >> m;
    int st, en; cin >> st >> en;

    for (int i = 0; i < m; i++) {
        int a, b; cin >> a >> b;
        char colour; cin >> colour;

        adj[a].push_back(b);
    }
    
    seen[st] = true;
    dfs(st);
    
    if (seen[en]) cout << "0";
    else cout << "IMPOSSIBLE";
    
}