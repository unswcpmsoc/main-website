#include <bits/stdc++.h>
using namespace std;
typedef long long ll;
#define int ll

int n,k;
char arr[1005];
bool knap[1005][1005];

signed main(){
    cin >> n >> k;
    for(int i=1;i<=n;i++){
        cin >> arr[i];
    }
    int mul = 1;
    knap[n+1][0] = true;
    for(int i=n;i>=1;i--){
        if(arr[i]=='0' or arr[i]=='?'){
            for(int j=0;j<k;j++){
                if(knap[i+1][j]){
                    knap[i][j] = true;
                }
            }
        }
        if(arr[i]=='1' or arr[i]=='?'){
            for(int j=0;j<k;j++){
                if(knap[i+1][(j-mul+k)%k]){
                    knap[i][j] = true;
                }
            }
        }
        mul *= 2;
        mul %= k;
    }
    if(knap[1][0]){
        cout << "NO SHIT" << "\n";
    }
    else{
        cout << "SHIT" << "\n";
    }
    return 0;
}