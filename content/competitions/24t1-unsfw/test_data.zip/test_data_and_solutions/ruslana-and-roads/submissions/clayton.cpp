// see prog_sol.cpp for explanations

#include <iostream>

using namespace std;

int main() {
    cout << "175/243" << endl;
}
