from mpmath import mp
mp.dps = 300005
with open("digits.txt", "w") as f:
    f.write(str(mp.sin(1))[2:300002])