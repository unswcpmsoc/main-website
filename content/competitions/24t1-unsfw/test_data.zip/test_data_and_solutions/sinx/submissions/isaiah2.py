# coding=utf-8
with open("digits.txt") as f:
    digits = f.read()
encoded = ""
def fix(n):
    return n + 1000 + 10000 * (n > 50000)
for i in range(0, len(digits), 5):
    encoded += chr(fix(int(digits[i:i+5])))
with open("encoded.txt", "w") as f:
    f.write(encoded)