// trans rights
#include <bits/stdc++.h>
using namespace std;
using ll = long long;
#define all(x) x.begin(), x.end()
#define sz(x) (int)(x).size()

int N, K;
string S;
int p2[1005];

bool dp[1005][1005];
int bit[1005][1005];

int main()
{
        cin.tie(0)->sync_with_stdio(0);
        cin >> N >> K;
        cin >> S;
        reverse(all(S));
        p2[0] = 1 % K;
        for (int i = 1; i < N; i++) p2[i] = (p2[i - 1] * 2) % K;
        dp[0][0] = 1;
        for (int i = 1; i <= N; i++) {
                char x = S[i - 1];
                for (int j = 0; j < K; j++) {
                        if (x == '0' or x == '?') {
                                if (dp[i - 1][j]) {
                                        dp[i][j] = 1;
                                }
                        }
                        if (x == '1' or x == '?') {
                                if (dp[i - 1][(j + (K - p2[i - 1])) % K]) {
                                        dp[i][j] = 1;
                                        bit[i][j] = 1;
                                }
                        }
                }
        }
        if (dp[N][0]) {
                cout << "NO SHIT\n";
                return 0;
                int j = 0;
                for (int i = N; i >= 1; i--) {
                        int b = bit[i][j];
                        cout << b;
                        if (b)
                                j = (j + (K - p2[i - 1])) % K;
                }
                return 0;
        }
        cout << "SHIT";
        return 0;
}
