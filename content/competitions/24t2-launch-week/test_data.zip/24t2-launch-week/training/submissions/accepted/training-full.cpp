#include <bits/stdc++.h>
using namespace std;

const int N = 1e5 + 5;

int adj[N], col[N];

int n, m, k, ans = 1;
vector <int> paths[N];

int main () {
    cin >> n >> m >> k;
    set <pair <int, int> > bfs;
    for (int i = 1; i <= m; i++) {
        int a, b; cin >> a >> b;
        paths[a].push_back(b);
        paths[b].push_back(a);
        adj[a]++;
        adj[b]++;
    }
    for (int i = 1; i <= n; i++) {
        bfs.insert({adj[i], i});
    }
    while(!bfs.empty()) {
        auto it = --bfs.end(); // picking a vertex that has two adjacent vertices in the same group
        int deg, pos; tie(deg, pos) = *it;
        if (deg < 2) {
            break;
        }
        bfs.erase(it);
        ans = 2;
        col[pos] ^= 1;
        adj[pos] = paths[pos].size()-adj[pos];
        for (auto& x : paths[pos]) {
            pair <int, int> tmp = {adj[x], x};
            bfs.erase(tmp);
            adj[x] += (col[pos] == col[x] ? 1 : -1);
            bfs.insert({adj[x], x});
        }
        bfs.insert({adj[pos], pos});
    }
    cout << ans << "\n";
    for (int i = 1; i <= n; i++) {
        cout << col[i]+1 << " \n"[i==n];
    }
} 