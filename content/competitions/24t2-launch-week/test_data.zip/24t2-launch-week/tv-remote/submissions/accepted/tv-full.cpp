#include <bits/stdc++.h>

using namespace std;

int n, k;
string s;

int simulate(int st) {
    for (int i = 0; i < n; i++) {
        if (s[i] == '+') {
            if (st + 1 <= k) st++;
        } else {
            if (st - 1 >= 1) st--;
        }
    }

    return st;
}

int main() {
    cin >> n >> k;
    cin >> s;

    cout << simulate(k) - simulate(1) + 1;
}