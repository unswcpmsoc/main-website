N = int(input())
A = list(map(int, input().split()))
ans = N
if min(A) == 0:
  ans -= 1
stack = [-1]
for a in A:
  while stack[-1] > a:
    stack.pop()
  if stack[-1] == a:
    ans -= 1
  stack.append(a)
print(ans)