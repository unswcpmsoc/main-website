#include <assert.h>
#include <stdlib.h>
#include <stdio.h>
#include <stdbool.h>

void IMPOSSIBLE() {
    printf("-1\n");
    exit(0);
}

int doMission(int numPenguins, int strengths[5], int mask) {
    bool avail[5] = {true, true, true, true, true};
    for (int i = 5; i >= 1; mask /= i, --i) {
        int ability = -1;
        for (int rep = 0; rep <= mask % i; ++rep) {
            ability++;
            while (!avail[ability]) ability++;
            assert(ability < 5);
            assert(avail[ability]);
        }
        // printf("%d ", ability);
        avail[ability] = false;

        switch (ability) {
            case 0: {
                numPenguins += strengths[ability];
                break;
            }
            case 1: {
                numPenguins -= strengths[ability];
                if (numPenguins < 0) return -1;
                break;
            }
            case 2: {
                numPenguins /= strengths[ability];
                break;
            }
            case 3: {
                numPenguins *= strengths[ability];
                break;
            }
            case 4: {
                if (numPenguins <= strengths[ability]) return -1;
                numPenguins += strengths[ability];
                break;
            }
        }
    }
    // printf("%d\n", numPenguins);
    return numPenguins;
}

int bruteforceMission(int prevPenguin, int strengths[5]) {
    int bestPenguin = -1;
    for (int mask = 0; mask < 120; ++mask) {
        int numPenguins = doMission(prevPenguin, strengths, mask);
        if (numPenguins > bestPenguin) {
            bestPenguin = numPenguins;
        }
    }

    if (bestPenguin == -1) IMPOSSIBLE();
    return bestPenguin;
}

int main() {
    int N, K;
    scanf("%d %d", &N, &K);
    int strengths[K][5];
    for (int i = 0; i < K; i++) {
        for (int j = 0; j < 5; j++) {
            scanf("%d", &strengths[i][j]);
        }
    }

    int numPenguins = N;
    for (int i = 0; i < K; ++i) {
        numPenguins = bruteforceMission(numPenguins, strengths[i]);
    }

    printf("%d\n", numPenguins);
}
