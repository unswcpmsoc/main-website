import itertools

N, K = map(int, input().split())
assert 0 <= N <= 10**9 and 1 <= K <= 10000
missions = [[int(strength) for strength in input().split()] for _ in range(K)]
assert all(0 <= min(mission) and max(mission) <= 10**9 for mission in missions)

def IMPOSSIBLE():
    print(-1)
    exit(0)

def findBest(numPenguin, perm):
    for (ability, strength) in perm:
        if ability == 'A':
            numPenguin += strength
        elif ability == 'B':
            numPenguin -= strength
            if numPenguin < 0: return -1
        elif ability == 'C':
            numPenguin //= strength
        elif ability == 'D':
            numPenguin *= strength
        elif ability == 'E':
            if numPenguin <= strength: return -1
            numPenguin += strength
        assert numPenguin <= 10**9
    return numPenguin

prevPenguin = N
for A, B, C, D, E in missions:
    bestPenguin = -1
    for perm in itertools.permutations([('A', A), ('B', B), ('C', C), ('D', D), ('E', E)]):
        currPenguin = findBest(prevPenguin, perm)
        # print(perm, currPenguin)
        if currPenguin > bestPenguin:
            bestPenguin = currPenguin

    if bestPenguin == -1: IMPOSSIBLE()
    prevPenguin = bestPenguin

print(prevPenguin)
