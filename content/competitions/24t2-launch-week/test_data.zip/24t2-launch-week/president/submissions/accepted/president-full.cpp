/**
 * Solution for president
 * time complexity: O(NM)
 * should pass all test cases
 */
#include <bits/stdc++.h>
using namespace std;

const int N = 1e3 + 5;
const int M = 1e6 + 5;

int par[M];
int nums[N];

bool flip;
int n, m, k, curLongest;
vector <vector <int> > ans;

int find(int x) { // disjoint set union
    if (par[x] == x) return x;
    return par[x] = find(par[x]);
}

bool merge(int x1, int y1, int x2, int y2) { // disjoint set union
    int a = find(x1*m+y1);
    int b = find(x2*m+y2);
    if (a == b) {
        return false;
    }
    
    par[a] = b;
    if (flip)
        ans.push_back({y1, x1, y2, x2});
    else
        ans.push_back({x1, y1, x2, y2});
    return true;
}

void expand(int x, int y, int dx, int dy) { // for expanding an endpoint
    while (curLongest < k) {
        if (y+dy >= 0 && y+dy < m && merge(x, y, x, y+dy)) {
            curLongest++;
            y += dy;
            continue;
        } else if (merge(x, y, x+dx, y)) {
            curLongest++;
            expand(x+dx, y, dx, -dy);
        }
        break;
    }
}

int main () {
    cin >> n >> m >> k;
    int lowerLimit = n+m-2;
    int upperLimit = n*m-1;
    if (n % 2 == 0 && m % 2 == 0) lowerLimit++;
    if (k < lowerLimit || upperLimit < k) {
        cout << "IMPOSSIBLE\n";
        return 0;
    }
    for (int i = 0; i < n*m; i++) 
        par[i] = i;

    if (m % 2 == 1) {
        flip = 1;
        swap(n, m);
    } else if (n % 2 == 0 && m % 2 == 0 && m == 2) {
        flip = 1;
        swap(n, m);
    }
    int h = (n-1)/2;
    if (n % 2 == 1) { // one of the sides are odd
        curLongest = n+m-2;
        for (int i = 0; i+1 < n; i++) {
            if (i+1 <= h) merge(i, 0, i+1, 0);
            else merge(i, m-1, i+1, m-1);
        }
        for (int j = 0; j+1 < m; j++) {
            merge(h, j, h, j+1);
        }
        expand(0, 0, 1, 1);
        expand(n-1, m-1, -1, -1);
    } else if (n*2 + m - 3 <= k) { // both sides are even but the required amount is big enough
        h = 0;
        curLongest = n*2 + m - 3;
        for (int i = 0; i+1 < n; i++) {
            merge(i, 0, i+1, 0);
            merge(i, m-1, i+1, m-1);
        }
        for (int j = 0; j+1 < m; j++) {
            merge(0, j, 0, j+1);
        }
        expand(n-1, m-1, -1, -1);
    } else { // both sides are even but the required amount is small enough
        curLongest = n + m - 1;
        for (int i = 0; i+1 < n; i++) {
            merge(i, 0, i+1, 0);
            merge(i, m-1, i+1, m-1);
        }
        for (int j = 0; j+1 < m; j++) {
            merge(h, j, h, j+1);
        }
        expand(n-1, m-1, -1, -1);
    }
    for (int j = 0; j < m; j++) {
        for (int d = -1; d < 2; d+=2)
        for (int i = 1; 0 <= h+d*i && h+d*i < n; i++) {
            int x1 = h+i*d;
            int x2 = h+(i-1)*d;
            merge(x1, j, x2, j);
        }
    }
    cout << "POSSIBLE\n";
    for (auto& x : ans) {
        cout << x[0]+1 << ' ' << x[1]+1 << ' ' << x[2]+1 << ' ' << x[3]+1 << '\n';
    }
}