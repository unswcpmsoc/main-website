N = 8
ans = 0
nums = list(map(int, input().split()))

for i in range(N):
    for j in range(i+1, N):
        ans += nums[i]*nums[j]
        
print(ans)