#include <bits/stdc++.h>
using namespace std;

int main() {
    int N = 8, ans = 0;
    int nums[N]; 
    for (int i = 0; i < N; i++) {
        cin >> nums[i];
    }
    for (int i = 0; i < N; i++) {
        for (int j = i+1; j < N; j++) {
            ans += nums[i]*nums[j];
        }
    }
    cout << ans << "\n";
}