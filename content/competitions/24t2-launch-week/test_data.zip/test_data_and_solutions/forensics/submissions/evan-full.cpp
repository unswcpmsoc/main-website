#include <bits/stdc++.h>
using namespace std;
typedef long long ll;
#define int ll

int n,ans;
int arr[300005];
bool zero;
set<int> s;

signed main(){
    cin >> n;
    for(int i=1;i<=n;i++){
        cin >> arr[i];
        if(arr[i]==0){
            zero = true;
        }
    }
    ans = n;
    if(zero){
        ans--;
    }
    for(int i=1;i<=n;i++){
        while(s.size()>0 and *prev(s.end())>arr[i]){
            s.erase(prev(s.end()));
        }
        if(s.size()>0 and *prev(s.end())==arr[i]){
            ans--;
        }
        s.insert(arr[i]);
    }
    cout << ans << "\n";
    return 0;
}