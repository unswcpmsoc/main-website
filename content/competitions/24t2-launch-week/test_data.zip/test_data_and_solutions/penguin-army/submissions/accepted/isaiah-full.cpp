#include <bits/stdc++.h>
using namespace std;
typedef long long ll;

ll N, K, a, b, c, d, e, perm[5];

int main() {
    for (ll i = 0; i < 5; i++) {
        perm[i] = i;
    }
    ll N, K;
    scanf("%lld%lld", &N, &K);
    for (ll i = 0; i < K; i++) {
        scanf("%lld%lld%lld%lld%lld", &a, &b, &c, &d, &e);
        ll best = -1;
        do {
            ll n = N;
            for (ll i = 0; i < 5; i++) {
                if (perm[i] == 0) n += a;
                if (perm[i] == 1) n -= b;
                if (perm[i] == 2) n /= c;
                if (perm[i] == 3) n *= d;
                if (perm[i] == 4) n = n > e ? n + e : -1;
                if (n < 0) break;
                assert(n <= 1e9);
            }
            best = max(best, n);
        } while (next_permutation(perm, perm + 5));
        N = best;
        if (best == -1) break;
    }
    printf("%lld\n", N);
}