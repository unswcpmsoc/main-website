#include <bits/stdc++.h>

using namespace std;

using ll = long long;

bool grid[8][1000005];

int main(){

    int n; cin >> n;

    vector<int> height(8, -1);

    for (int i = 0; i < n; i++) {
        int type; cin >> type;
        if (type == 1) {
            int col; cin >> col;

            int curHeight = height[col];
            grid[col][++curHeight] = true;
            grid[col][++curHeight] = true;
            height[col] = curHeight;
        } else {
            int col1; cin >> col1;
            int col2 = col1 + 1;

            int curHeight = max(height[col1], height[col2]);
            curHeight++;
            grid[col1][curHeight] = grid[col2][curHeight] = true;
            height[col1] = height[col2] = curHeight;
        }
    }

    int maxH = -1;
    for (int i = 1; i <= 7; i++) maxH = max(maxH, height[i]);

    if (maxH == -1) return 0;

    for (int row = maxH; row >= 0; row--) {
        for (int j = 1; j <= 7; j++) {
            if (grid[j][row]) cout << "*";
            else cout << "-";
        }
        cout << endl;
    }
}