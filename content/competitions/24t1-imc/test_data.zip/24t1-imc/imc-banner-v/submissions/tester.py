import random
import subprocess
random.seed(0)
tries = 0
while tries < 1000:
    tries += 1
    with open("test.in", "w") as f:
        # Replace everything in here to be specific to the problem,
        # this is just an example.
        N = random.randint(3,10)
        f.write(str(N) + "\n")
        A = [random.choice("IMC") for i in range(N)]
        f.write("".join(A) + "\n")
        
    result1 = subprocess.check_output("./broken < test.in", shell=True)
    result2 = subprocess.check_output("./correct < test.in", shell=True)
    if result1 != result2:
        print("gg", tries)
        print(result1, result2)
        break  