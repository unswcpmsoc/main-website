#include <bits/stdc++.h>
using namespace std;
typedef long long ll;

int N;
char S[300005];

int main() {
    cin >> N >> S;
    ll ans = 0;
    for (int i = 0; i < N; i++) {
        if (S[i] == 'M') {
            for (int x = 1; 0 <= i-x && i+x < N; x++) {
                if (S[i-x] == 'I' && S[i+x] == 'C') {
                    ans += 1;
                }
            }
        }
    }
    cout << ans << "\n";
}