// each component has an even number of nodes coloured
// this can be done in nC0 + nC2 + ... ways = 2^(n-1)
// ans = prod_C 2^(|C| - 1) = 2^(N - num components)

#include <bits/stdc++.h>
#include <unordered_map>
using namespace std;

int R, C, N;
// rows labeled 1 to R, cols labeled R+1 to R+C
int Rcount, Ccount;
unordered_set<int> nodes;
unordered_map<int, vector<int>> G;
unordered_set<int> seen;

// this gets stack overflow :/
// TODO: get working on cpmsoc judge
// void markComponent(int u) {
//     seen.insert(u);
//     assert(seen.size() <= nodes.size());
//     for (int v : G[u]) {
//         if (seen.count(v)) continue;
//         markComponent(v);
//     }
// }

int markComponent(int start) {
    queue<int> q;
    q.push(start);
    seen.insert(start);
    int total = 0;
    while (!q.empty()) {
        int u = q.front();
        q.pop();
        total++;
        for (int v : G[u]) {
            if (seen.count(v)) continue;
            q.push(v);
            seen.insert(v);
        }
    }
    return total;
}

signed main() {
    cin.tie(0); ios::sync_with_stdio(0);
    cin >> R >> C >> N;
    for (int r, c, i = 0; i < N; ++i) {
        cin >> r >> c;
        c += R + 1;
        if (!nodes.count(r)) {
            Rcount++;
            nodes.insert(r);
        }
        if (!nodes.count(c)) {
            Ccount++;
            nodes.insert(c);
        }
        G[r].push_back(c);
        G[c].push_back(r);
    }

    bool canToggleAll = Rcount == R || Ccount == C;

    int numComponents = 0;
    for (int node : nodes) {
        if (seen.count(node)) continue;
        numComponents++;
        markComponent(node);
        if (seen.size() % 2 == 1) canToggleAll = false;
    }

    long long ans = 1;
    for (int i = 1; i <= nodes.size() - numComponents - canToggleAll; i++) {
        ans = (ans * 2) % 1000000007;
    }
    cout << ans << "\n";
}
