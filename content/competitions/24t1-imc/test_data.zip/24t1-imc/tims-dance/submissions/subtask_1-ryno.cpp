#include <bits/stdc++.h>
#include <iomanip>
using namespace std;

int R, C, N;
vector<pair<int, int>> cells;

bool isEmpty(int bits) {
    vector<vector<bool>> grid(R, vector<bool>(C, 0));
    for (int i = 0; i < N; ++i) {
        if ((bits & (1 << i)) == 0) continue;
        auto [r, c] = cells[i];
        for (int c_ = 0; c_ < C; ++c_) grid[r][c_] = !grid[r][c_];
        for (int r_ = 0; r_ < R; ++r_) grid[r_][c] = !grid[r_][c];
    }
    for (int r = 0; r < R; ++r) {
        for (int c = 0; c < C; ++c) {
            if (grid[r][c]) return false;
        }
    }
    return true;
}

signed main() {
    cin.tie(0); ios::sync_with_stdio(0);
    cin >> R >> C >> N;
    for (int r, c, i = 0; i < N; ++i) {
        cin >> r >> c;
        cells.push_back({r, c});
    }

    vector<int> good;
    for (int bits = 0; bits < (1 << N); ++bits) {
        bool unique = true;
        for (int prev : good) {
            unique &= !isEmpty(bits ^ prev);
        }
        if (unique) {
            // cout << bits << "\n";
            good.push_back(bits);
        }
    }

    cout << fixed << setprecision(3);
    cout << log10(good.size());
}
