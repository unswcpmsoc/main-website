#include <bits/stdc++.h>
using namespace std;

int M, C, c[1005], p[1005], need[1005];

bool seen[1005][1005];
int cache[1005][1005];
// min sum of squares if you are up to item i and have spent j dollars
int dp(int i, int j) {
    if (j < need[i-1]) {
        return 1e9;
    }
    if (i == M+1) {
        return 0;
    }
    if (seen[i][j]) {
        return cache[i][j];
    }
    seen[i][j] = true;
    cache[i][j] = 1e9;
    for (int k = 0; k <= 1000-j; k++) {
        cache[i][j] = min(cache[i][j], k*k + dp(i+1, j+k));
    }
    return cache[i][j];
}

int main() {
    cin >> M >> C;
    for (int i = 1; i <= C; i++) {
        cin >> c[i] >> p[i];
        for (int j = c[i]; j <= M; j++) {
            need[j] = max(need[j], p[i]);
        }
    }
    cout << dp(1, 0) << "\n";
}