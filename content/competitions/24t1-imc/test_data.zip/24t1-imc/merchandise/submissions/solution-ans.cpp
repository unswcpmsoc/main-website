#include <iostream>
#include <vector>
#include <algorithm>

using namespace std;

int main(void) {
    int M, C;
    cin >> M >> C;
    vector<pair<pair<int, int>, int>> q;

    for (int i = 0; i < C; i++) {
        bool no_loop = true;
        int c, p;
        cin >> c >> p;
        pair<pair<int, int>, int> info;
        while (!q.empty()) {
            no_loop = false;
            int u = q.back().first.first;
            int v = q.back().first.second;
            int w = q.back().second;
            int S = u * w + v;
            int a = (p - S) / (c - w);
            int b = (p - S) % (c - w);
            info = {{a, b}, c};
            if (info <= q.back()) {
                break;
            }

            q.pop_back();
        }
        if (q.empty()) {
            info = {{p / c, p % c}, c};
        }

        q.push_back(info);
    }
    int so_far = 0, ans = 0;
    for (pair<pair<int, int>, int> g : q) {
        int a = g.first.first;
        int b = g.first.second;
        int c = g.second;
        for (int i = 0; i < c - so_far; i++) {
            if (b) {
                b--;
                ans += max(a + 1, 0) * max(a + 1, 0);
            } else {
                ans += max(a, 0) * max(a, 0);
            }
        }
        so_far = c;
    }
    cout << ans << "\n";
}