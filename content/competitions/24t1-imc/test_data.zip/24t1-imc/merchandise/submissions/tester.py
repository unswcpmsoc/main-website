import random
import subprocess
random.seed(0)
tries = 0
while tries < 100:
    tries += 1
    with open("test.in", "w") as f:
        # Replace everything in here to be specific to the problem,
        # this is just an example.
        M, C = random.randint(3,3), random.randint(3,3)
        cs = sorted(set(random.randint(1,M) for i in range(C)))

        C = len(cs)
        f.write(f"{M} {C}\n")
        for i in range(C):
            c = cs[i]
            p = random.randint(1,100)
            f.write(f"{c} {p}\n")
        
    result1 = subprocess.check_output("./broken < test.in", shell=True)
    result2 = subprocess.check_output("./correct < test.in", shell=True)
    if result1 != result2:
        print("gg", tries)
        print(result1, result2)
        break   