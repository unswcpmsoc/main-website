input()

print(0)