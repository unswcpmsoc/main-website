#include <bits/stdc++.h>
using namespace std;

int N, pre[7][300005];
char S[300005], pieces[] = "IOTJSZL";
int main() {
    cin >> N >> (S+1);
    for (int piece = 0; piece < 7; piece++) {
        for (int i = 1; i <= N; i++) {
            pre[piece][i] = pre[piece][i-1] + (S[i] == pieces[piece]);
        }
    }
    int bagsize = 0;
    bool works = false;
    while (!works) {
        bagsize += 7;
        works = true;
        for (int i = 1; i <= N; i += bagsize) { // i is first element in bag
            for (int piece = 0; piece < 7; piece++) {
                if (pre[piece][min(i + bagsize - 1, N)] - pre[piece][i - 1] > bagsize / 7) {
                    works = false;
                    break;
                }
            }
            if (!works) break;
        }
    }
    cout << bagsize << "\n";
}