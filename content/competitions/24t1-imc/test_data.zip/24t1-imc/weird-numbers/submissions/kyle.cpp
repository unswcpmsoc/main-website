#include <iostream>


using namespace std;


using ll = uint64_t;

ll gettoadd(ll n) {
    if (n == 0) return 1;
    ll toadd = 1;
    for (int i = 1; i <= n; i++) {
        toadd *= 10;
    }
    return toadd;
}

int main(){
    ll n; cin >> n;

    n++;

    while (true) {
        string rep = to_string(n);

        bool valid = true;

        for (int i = 1; i < rep.size(); i++) {
            if (rep[i] == rep[i-1]) {
                ll toadd = gettoadd(rep.size() - i - 1);
                n += toadd;
                n = n / toadd * toadd;
                valid = false;
                break;
            }
        }

        if (valid) {
            cout << n;
            break;
        }
        else continue;
    }
}