sides = list(map(int, input().split()))
sides = sorted(sides)

if sides[0] + sides[1] <= sides[2]: print("NOT A TRIANGLE")
elif sides[0] == sides[1] and sides[0] == sides[2]: print("EQUILATERAL")
elif sides[0] == sides[1] or sides[1] == sides[2]: print("ISOSCELES")
elif sides[0]**2 + sides[1]**2 == sides[2]**2: print("RIGHT ANGLED")
else: print("SCALENE")