import math

def ans(n):
    m = math.ceil((math.sqrt(1 + 8*n) - 1)/2)
    mfloor = math.floor((math.sqrt(1 + 8*n) - 1)/2)
    extra = n-(mfloor*(mfloor+1)/2)
    person = m%3 if m%3 != 0 else 3

    if extra == 0:
        return (1+(m - person)/3)*(person + m)/2

    taken = ((m - person)/3)*(person + m - 3)/2

    return int(taken+extra)

print(int(ans(int(input()))))