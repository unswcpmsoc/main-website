#include<stdio.h>

long long int n;
long long int answer;

int bs() {
    int l = 0;
    int r = 1000000000;
    int best = 0;
    while (l <= r) {
        long long int mid = (l+r) /2;
        if ((mid*(mid+1))/2 <= n) {
            best = mid;
            l = mid+1;
        } else r = mid-1;
    }
    return best;
}

int main() {
    scanf("%lld", &n);
    long long int last_full = bs();
    long long int extra = n - (last_full * (last_full + 1)) / 2;
    if (extra != 0) last_full -= 2;
    printf("%lld", ((last_full + (last_full % 3)) * (last_full/3+1))/2 + extra);
    return 0;
}