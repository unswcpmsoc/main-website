#include <iostream>
using namespace std;

void printGlowingTree(int height) {
    int i, j, k;
    for (i = 1; i <= height; i++) {
        // Print dots
        for (j = 1; j <= height - i; j++) {
            cout << ".";
        }
        // Print asterisks
        for (k = 1; k <= 2 * i - 1; k++) {
            cout << "*";
        }

        for (j = 1; j <= height - i; j++) {
            cout << ".";
        }

        cout << "\n";
    }
}

int main() {
    int height;
    scanf("%d", &height);
  
    printGlowingTree(height);

    // print trunk:
    int i, j;
    int trunk_length = height / 3 + 1;
    for (i = 1; i <= trunk_length; i++) {
        for (j = 1; j <= height - 1; j++) {
            cout << ".";
        }

        cout << "*";

        for (j = 1; j <= height - 1; j++) {
            cout << ".";
        }

        cout << "\n";
    }
    
    return 0;
}
