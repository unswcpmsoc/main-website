N = int(input())
ans = 0
for i in range(N):
    row = list(map(int, input().split()))
    for j in range(N):
        if row[j] == (i+1)*(j+1):
            ans += 1
print(ans)