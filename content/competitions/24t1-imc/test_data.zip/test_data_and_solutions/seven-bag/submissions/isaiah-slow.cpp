#include <bits/stdc++.h>
using namespace std;

int N, pre[7][300005];
char S[300005], pieces[] = "IOTJSZL";
int main() {
    cin >> N >> (S+1);
    int bagsize = 0;
    bool works = false;
    while (!works) {
        bagsize += 7;
        works = true;
        for (int i = 1; i <= N; i += bagsize) { // i is first element in bag
            for (int piece = 0; piece < 7; piece++) {
                int cnt = 0;
                for (int j = i; j <= min(i + bagsize - 1, N); j++) {
                    cnt += (pieces[piece] == S[j]);
                }
                if (cnt > bagsize / 7) {
                    works = false;
                    break;
                }
            }
            if (!works) break;
        }
    }
    cout << bagsize << "\n";
}