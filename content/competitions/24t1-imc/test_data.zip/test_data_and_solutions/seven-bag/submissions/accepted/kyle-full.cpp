#include <bits/stdc++.h>

using namespace std;

map<char, int> m = {
        {'I', 0}, {'O', 1}, {'T', 2}, {'J', 3}, {'S', 4}, {'Z', 5}, {'L', 6}
};

int diff[7][3000005];
int csum[7][3000005];

int main(){
    int n; cin >> n;

    for (int i = 1; i <= n; i++) {
        char c; cin >> c;
        diff[m[c]][i]++;
    }

    for (int i = 0; i < 7; i++) {
        for (int j = 1; j <= 3000000; j++) {
            csum[i][j] = csum[i][j-1] + diff[i][j];
        }
    }

    for (int bagsize = 7; bagsize <= n*7; bagsize += 7) {
        bool valid = true;
        for (int j = bagsize; j <= n + bagsize + 7; j += bagsize) {
            for (int i = 0; i < 7; i++) {
//                cout << csum[i][j] << " " << csum[i][j - bagsize] << " " << i << " " << j << " " << bagsize << endl;
                if (csum[i][j] - csum[i][j - bagsize] > bagsize / 7) {
                    valid = false;
                    break;
                }
            }
            if (!valid) break;
        }

        if (valid) {
            cout << bagsize;
            return 0;
        }
    }
}