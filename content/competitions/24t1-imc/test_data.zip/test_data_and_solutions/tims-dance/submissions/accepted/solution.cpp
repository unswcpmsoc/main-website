#include <iostream>
#include <vector>
#include <map>
#include <set>
#include <cmath>

using namespace std;

set<int> rseen;
set<int> cseen;
map<int, vector<int>> cols_in_row;
map<int, vector<int>> rows_in_col;

int dfs(int node, bool is_row);

int main(void) {
    int R, C, N;
    set<int> row_traversals;
    set<int> col_traversals;
    bool odd_span = true;
    int e = 0;

    cin >> R >>C >> N;
    for (int i = 0; i < N; i++) {
        int r, c;
        cin >> r >> c;

        cols_in_row[r].push_back(c);
        rows_in_col[c].push_back(r);
        row_traversals.insert(r);
        col_traversals.insert(c);
    }

    for (int r : row_traversals) {
        if (rseen.find(r) != rseen.end()) continue;
        rseen.insert(r);
        int count = dfs(r, true);
        if (count % 2 == 1) {
            odd_span = false;
        }
        e += count - 1;
    }

    for (int c : col_traversals) {
        if (cseen.find(c) != cseen.end()) continue;
        cseen.insert(c);
        int count = dfs(c, false);
        if (count % 2 == 1) {
            odd_span = false;
        }
        e += count - 1;
    }
    int s = 1;
    for (int i = 0; i < (int) ((e-(odd_span && row_traversals.size() == R && col_traversals.size() == C))); i++) {
        s = (s * 2) % (1000000007);
    }

    cout << s;
}

int dfs(int node, bool is_row) {
    int s = 0;
    if (is_row) {
        for (int c : cols_in_row[node]) {
            if (cseen.find(c) == cseen.end()) {
                cseen.insert(c);
                s += dfs(c, false);
            }
        }
    } else {
        for (int r : rows_in_col[node]) {
            if (rseen.find(r) == rseen.end()) {
                rseen.insert(r);
                s += dfs(r, true);
            }
        }
    }

    return s + 1;
}