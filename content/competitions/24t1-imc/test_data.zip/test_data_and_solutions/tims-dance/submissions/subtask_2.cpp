#include <iostream>
#include <bitset>
#include <stack>
#include <set>
#include <cmath>
#include <iomanip>
#include <unordered_set>

using namespace std;

typedef std::size_t length_t, position_t;
typedef bitset<20000> state;

struct point {
    int r;
    int c;
};

struct point switches[10];
unordered_set<state> possible_states;
int R, C, N;

void dfs(state mask, int depth=0);

int main(void) {
    cin >> R >> C >> N;
    set<int> rows_used;
    set<int> columns_used;

    for (int i = 0; i < N; i++) {
        cin >> switches[i].r >> switches[i].c;
        rows_used.insert(switches[i].r);
        columns_used.insert(switches[i].c);
    }

    dfs(0);
    size_t s = possible_states.size();
    if (R == rows_used.size() && C == columns_used.size()) {
        s -= pow(2, R + C - 1 - ((R + C) % 2));
    }

    cout << s;
}

void dfs(state mask, int depth) {
    if (depth == N-1) {
        possible_states.insert(mask);
    } else {
        dfs(mask, depth+1);
    }

    mask.flip(switches[depth].r);
    mask.flip(R + switches[depth].c);

    if (depth == N-1) {
        possible_states.insert(mask);
    } else {
        dfs(mask, depth+1);
    }
}