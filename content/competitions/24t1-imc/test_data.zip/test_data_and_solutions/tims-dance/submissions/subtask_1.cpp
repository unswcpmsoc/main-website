#include <iostream>
#include <bitset>
#include <stack>
#include <vector>
#include <cmath>
#include <iomanip>
#include <unordered_set>

using namespace std;

typedef std::size_t length_t, position_t;

class DynamicBitset {
    int R, C;
    public:
    vector<uint32_t> s;
    DynamicBitset(int R, int C) : R(), C() {
        s = vector<uint32_t>((R * C -1) / sizeof(int)+1, 0); // ceil(R*C/sizeof(int))
    }

    void flip(int offset) {
        s[offset / sizeof(int)] ^= (1 << (offset % sizeof(int)));
    }

    int count() {
        int c = 0;
        for (int part : s) {
            c += __builtin_popcount(part);
        }

        return c;
    }

    bool operator==(const DynamicBitset& other) const {
        return (s == other.s);
    }


};

class BitsetHash {
    public:
    // yoinked from https://stackoverflow.com/questions/20511347/a-good-hash-function-for-a-vector/72073933#72073933
    size_t operator()(const DynamicBitset &b) const  {
        std::size_t seed = b.s.size();
        for (auto x : b.s) {
            x = ((x >> 16) ^ x) * 0x45d9f3b;
            x = ((x >> 16) ^ x) * 0x45d9f3b;
            x = (x >> 16) ^ x;
            seed ^= x + 0x9e3779b9 + (seed << 6) + (seed >> 2);
        }
        return seed;
    }
};

struct point {
    int r;
    int c;
};

struct point switches[10];
unordered_set<DynamicBitset, BitsetHash> possible_states;
int R, C, N;

void dfs(DynamicBitset mask, int depth=0);

int main(void) {
    cin >> R >> C >> N;

    for (int i = 0; i < N; i++) {
        cin >> switches[i].r >> switches[i].c;
    }

    dfs(DynamicBitset(R, C));

    cout << fixed << setprecision(3) << log10(possible_states.size());
}

void dfs(DynamicBitset mask, int depth) {
    if (depth == N-1) {
        possible_states.insert(mask);
    } else {
        dfs(mask, depth+1);
    }

    for (int ri = 0; ri < R; ri++) {
        mask.flip(ri * C + switches[depth].c);
    }

    for (int ci = 0; ci < C; ci++) {
        mask.flip(switches[depth].r * C + ci);
    }
    
    if (depth == N-1) {
        possible_states.insert(mask);
    } else {
        dfs(mask, depth+1);
    }
}