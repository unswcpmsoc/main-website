#include <bits/stdc++.h>
using namespace std;
typedef long long ll;

ll N, A[1005], sorted[1005], dp[1005][1005];
// dp[i][j] = min score up to index i, last value is at most sorted[j]

int main() {
    cin >> N;
    for (ll i = 1; i <= N; i++) {
        cin >> A[i];
        sorted[i] = A[i];
    }
    sort(sorted+1, sorted+N+1);
    for (ll i = 1; i <= N; i++) {
        dp[i][0] = 1e18;
        for (ll j = 1; j <= N; j++) {
            dp[i][j] = min(dp[i-1][j] + abs(A[i] - sorted[j]), dp[i][j-1]);
            // cout << dp[i][j] << " ";
        }
        // cout << "\n";
    }
    cout << dp[N][N] << "\n";
}