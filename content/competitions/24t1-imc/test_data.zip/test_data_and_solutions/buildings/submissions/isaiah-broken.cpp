#include <bits/stdc++.h>
using namespace std;

int N, A;
multiset<int> ms[100005];
multiset<int>::iterator lowermed[100005], uppermed[100005];
vector<int> chunks;

void insert(int i, int x) {
    ms[i].insert(x);
    if (ms[i].size() % 2 == 0) {
        if (x >= *uppermed[i]) uppermed[i]++;
        if (x < *lowermed[i]) lowermed[i]--;
    } else {
        if (x >= *lowermed[i]) lowermed[i]++;
        if (x < *uppermed[i]) uppermed[i]--;
    }
}

int main() {
    cin >> N;
    for (int i = 1; i <= N; i++) {
        cin >> A;
        ms[i].insert(A);
        lowermed[i] = ms[i].begin();
        uppermed[i] = ms[i].begin();
        chunks.push_back(i);
        while (true) {
            if (chunks.size() < 2) break;
            int a = chunks[chunks.size()-2];
            int b = chunks[chunks.size()-1];
            if (*lowermed[a] <= *uppermed[b]) break;
            if (ms[a].size() < ms[b].size()) swap(a, b);
            for (int x: ms[b]) {
                insert(a, x);
            }
            chunks.pop_back();
            chunks.back() = a;
        }
    }
    long long ans = 0;
    for (int i: chunks) {
        cout << "chunk " << i << "\n";
        for (int x: ms[i]) {
            cout << x << "\n";
            ans += abs(x - *lowermed[i]);
        }
    }
    cout << ans << "\n";
}