#include <bits/stdc++.h>
using namespace std;
typedef long long ll;

int N;
char S[300005];

int main() {
    cin >> N >> S;
    ll ans = 0;
    for (int i = 0; i < N; i++) {
        for (int x = 1; i+2*x < N; x++) {
            if (S[i] == 'I' && S[i+x] == 'M' && S[i+2*x] == 'C') {
                ans += 1;
            }
        }
    }
    cout << ans << "\n";
}