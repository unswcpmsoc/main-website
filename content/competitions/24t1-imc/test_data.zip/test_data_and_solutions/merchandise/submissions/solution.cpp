#include <iostream>
#include <vector>
#include <algorithm>

using namespace std;

int main(void) {
    int M, C;
    cin >> M >> C;
    vector<pair<pair<int, int>, pair<int, int>>> q;
    int max_so_far = 0;

    for (int i = 0; i < C; i++) {
        bool no_loop = true;
        int c, p;
        cin >> c >> p;
        p = max(max_so_far, p);
        max_so_far = p;
        pair<pair<int, int>, pair<int, int>> info;
        while (!q.empty()) {
            no_loop = false;
            int u = q.back().first.first;
            int v = q.back().first.second;
            int x = q.back().second.first;
            int w = q.back().second.second;
            int S = u * w + v;
            int a = (p - x) / (c - w);
            int b = (p - x) % (c - w);
            info = {{a, b}, {p, c}};
            if (info <= q.back()) {
                break;
            }

            q.pop_back();
        }
        if (q.empty()) {
            info = {{p / c, p % c}, {p, c}};
        }

        q.push_back(info);
    }
    int so_far = 0;
    long long s = 0;
    for (pair<pair<int, int>, pair<int, int>> g : q) {
        long long a = g.first.first;
        int b = g.first.second;
        int c = g.second.second;
        for (int i = 0; i < c - so_far; i++) {
            if (b) {
                b--;
                s += max(a + 1, 0LL)*max(a + 1, 0LL);
                
            } else {
                s += max(a, 0LL)*max(a, 0LL);
            }
        }
        so_far = c;
    }

    cout << s;
}