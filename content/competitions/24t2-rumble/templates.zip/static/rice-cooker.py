# This line reads the input.
A, B = map(int, input().split())

# TODO: compute the answer!
answer = -1

# This line outputs the answer.
print(answer)