# This line reads the input.
N = int(input())

# TODO: print the answer!
print('TODO')