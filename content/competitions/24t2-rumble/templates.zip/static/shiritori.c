#include <stdio.h>

const int MAX_N = 100, MAX_LENGTH = 20;

int main() {
    // These lines read the input.
    int N;
    char words[MAX_N][MAX_LENGTH+1];
    scanf("%d", &N);
    for (int i = 0; i < N; i++) {
        scanf("%s", words[i]);
    }

    // For example, first_letter stores the first letter of the first word.
    char first_letter = words[0][0];

    // TODO: calculate and print the answer!
    printf("-1\n");
    printf("%s\n", words[0]);
}