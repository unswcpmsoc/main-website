# This line reads the input.
n = int(input())

# TODO: compute the answer!
answer = -1

# This line outputs the answer.
print(answer)