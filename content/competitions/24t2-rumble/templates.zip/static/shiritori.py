# This line reads the input.
N = int(input())
words = [input().strip() for _ in range(N)]

# For example, first_letter stores the first letter of the first word.
first_letter = words[0][0]

# TODO: calculate and print the answer!
print(-1)
print(words[0])