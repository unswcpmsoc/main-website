#include <stdio.h>

const int MAX_N = 25000;

int main() {
    // These lines read the input.
    int N1, A1, B1, tastiness1[MAX_N];
    scanf("%d%d%d", &N1, &A1, &B1);
    for (int i = 0; i < N1; i++) {
        scanf("%d", &tastiness1[i]);
    }
    int N2, A2, B2, tastiness2[MAX_N];
    scanf("%d%d%d", &N2, &A2, &B2);
    for (int i = 0; i < N2; i++) {
        scanf("%d", &tastiness2[i]);
    }
    int N3, A3, B3, tastiness3[MAX_N];
    scanf("%d%d%d", &N3, &A3, &B3);
    for (int i = 0; i < N3; i++) {
        scanf("%d", &tastiness3[i]);
    }
    int N4, A4, B4, tastiness4[MAX_N];
    scanf("%d%d%d", &N4, &A4, &B4);
    for (int i = 0; i < N4; i++) {
        scanf("%d", &tastiness4[i]);
    }
    int K;
    scanf("%d", &K);

    // For example, sum_of_first stores the sum of the tastiness values of the first carrot of each type.
    int sum_of_first= tastiness1[0] + tastiness2[0] + tastiness3[0] + tastiness4[0];

    // TODO: compute the answer!
    int answer = -1;

    // This line outputs the answer.
    printf("%d\n", answer);
}