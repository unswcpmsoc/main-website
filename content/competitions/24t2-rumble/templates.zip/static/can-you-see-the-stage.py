# These lines read the input.
N, M = map(int, input().split())
heights = [list(map(int, input().split())) for _ in range(N)]

# For example, sum_corners stores the top left height plus the bottom right height.
sum_corners = heights[0][0] + heights[N-1][M-1]

# TODO: print the answer!
print("MAYBE")