#include <stdio.h>

int main() {
    // These lines read the input.
    int A, B, C;
    scanf("%d%d%d", &A, &B, &C);

    // TODO: compute and output the answer!
    printf("2\n");
    printf("2 1 2\n");
    printf("2 2 2\n");
}