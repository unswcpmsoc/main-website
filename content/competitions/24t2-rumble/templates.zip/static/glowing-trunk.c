#include <stdio.h>

int main() {
    // These lines read the input.
    int N;
    scanf("%d", &N);

    // TODO: print the answer!
    printf("TODO");
}