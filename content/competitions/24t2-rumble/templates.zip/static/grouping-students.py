# This line reads the input.
A, B, C = map(int, input().split())

# TODO: compute the groups!
groups = []
groups.append([1, 2])
groups.append([2, 2])

# This line outputs the groups.
for group in groups:
    print(len(group), *group)