import sys
sys.setrecursionlimit(1_000_000)

A, B, C = list(map(int, input().split()))

cache = {}
def solve(a, b, c):
    if a < 0 or b < 0 or c < 0:
        return False
    if (a, b, c) in cache:
        return cache[(a, b, c)]
    if a == 0 and b == 0 and c == 0:
        cache[(a, b, c)] = True
        return cache[(a, b, c)]
    for x, y, z in [(1, 0, 0), (1, 1, 0), (0, 2, 0), (2, 0, 1), (1, 0, 2), (0, 0, 3)]:
        if solve(a-x, b-y, c-z):
            cache[(a, b, c)] = True
            return cache[(a, b, c)]
    for x in range(7):
        for y in range(7-x):
            z = 6-x-y
            if solve(a-x, b-y, c-z):
                cache[(a, b, c)] = True
                return cache[(a, b, c)]
    cache[(a, b, c)] = False
    return cache[(a, b, c)]

print(0 if solve(A, B, C) else -1)
