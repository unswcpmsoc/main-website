A, B, C = list(map(int, input().split()))
students = {
    1: [1] * A,
    2: [2] * B,
    3: [3] * C,
}

def solve(used):
    left = {
        1: len(students[1]) - used[1],
        2: len(students[2]) - used[2],
        3: len(students[3]) - used[3],
    }

    if left[1] >= left[2] % 2 + (-left[3]) % 3:
        while left[2] % 2 != 0:
            left[2] += 1
            students[2].append(students[1].pop())
        while left[3] % 3 != 0:
            left[3] += 1
            students[3].append(students[1].pop())

        groups = []
        if used[1] + used[2] + used[3] == 6:
            groups.append(students[1][:used[1]] + students[2][:used[2]] + students[3][:used[3]])
        for sz in [1, 2, 3]:
            for i in range(used[sz], len(students[sz]), sz):
                groups.append(students[sz][i:i+sz])
        print(len(groups))
        for group in groups:
            print(len(group), *group)
        exit()

solve({1: 0, 2: 0, 3: 0})
for ones in range(min(len(students[1]), 6) + 1):
        for twos in range(min(len(students[2]), 6 - ones) + 1):
            threes = 6 - ones - twos
            if threes <= len(students[3]):
                solve({1: ones, 2: twos, 3: threes})
    
print(-1)