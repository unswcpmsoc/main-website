n = int(input())

ans = 0
x = n + 1
while True:
    y = (n * x) / (x - n)

    if y.is_integer():
        ans += 1
        print(x, int(y))

    if y < x:
        break

    x += 1

print(ans * 2 - 1)