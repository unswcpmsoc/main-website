n = int(input())

ans = 1
i = 2
while i * i <= n:
    cnt = 0
    while n % i == 0:
        n //= i
        cnt += 1
    ans *= 2 * cnt + 1
    i += 1
if n > 1:
    ans *= 3

print(ans)