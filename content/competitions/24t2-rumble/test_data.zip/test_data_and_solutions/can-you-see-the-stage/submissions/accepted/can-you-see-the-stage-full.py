N, M = map(int, input().split())

seats = []

for _ in range(N):
    row = list(map(int, input().split()))
    seats.append(row)
    
answer = True
for j in range(M):
    for i in range(1, N):
        if seats[i][j] <= seats[i-1][j]:
            answer = False;

if (answer):
    print("YES")
else:
    print("NO")