#include <bits/stdc++.h>
using namespace std;

int main() {
    int N, M;
    cin >> N >> M;
    int seats[N][M];
    for (int i = 0; i < N; i++) {
        for (int j = 0; j < M; j++) {
            cin >> seats[i][j];
        }
    }
    bool answer = true;
    for (int j = 0; j < M; j++) {
        for (int i = 1; i < N && answer; i++) {
            if (seats[i][j] <= seats[i-1][j]) {
                answer = false;
            }
        }
    }
    if (answer) {
        cout << "YES\n";
    } else {
        cout << "NO\n";
    }
}