N, M = map(int, input().split())
height = [list(map(int, input().split())) for _ in range(N)]

prev = -1
for j in range(M):
    for i in range(N):
        if height[i][j] <= prev:
            print("NO")
            exit(0)
        prev = height[i][j]
    prev = -1

print("YES")
