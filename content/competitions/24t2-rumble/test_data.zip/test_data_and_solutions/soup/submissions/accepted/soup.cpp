#include <iostream>
#include <vector>
#include <algorithm>

using namespace std;

// enum veggies{
//      carrots = 0, 
//      tomatoes = 1,
//      onions = 2, 
//      lamb = 3,
// };

int a[4];
int b[4];
int added[4];
vector<int> ingredients [4];
vector<pair<int, int>> allIngredients;
int k;

// carrot, tomato, onion, lamb,  
int main(void) {
    // input:
    /*
    k 
    nCarrot aCarrot bCarrot
    carrots 
    ... tomato, onion, lamb 
    */ 
     for (int i = 0; i < 4; i++) {
          int l;
          cin >> l >> a[i] >> b[i];
          for (int blah = 0; blah < l; blah++) {
               int quality;
               cin >> quality;
               ingredients[i].push_back(quality);
          }
     }
     cin >> k;

     // sort each type of ingredient and add a[i] of the best quality of that type into the soup 
     // exit if not enough
     int totalQuality = 0;
     for (int i = 0; i < 4; i++) {
          sort(ingredients[i].begin(), ingredients[i].end());
          added[i] = 0; 
          while (added[i] < a[i] && !ingredients[i].empty()) {
               totalQuality += ingredients[i].back();
               k--;
               added[i]++;
               ingredients[i].pop_back();
          }
          if (added[i] < a[i]) {
               // cout << a[i]  << " " << added[i] << "\n";
               cout << -1;
               return 0;
          }
     }
     
     // put the rest of the remainding ingredients all into a big list (pairs of <quality of ingredient, type of ingredient>)
     for (int i = 0; i < 4; i++) {
          for (auto thing: ingredients[i]) {
               allIngredients.push_back({thing, i});
          }
     }
     // sort them 
     sort(allIngredients.begin(), allIngredients.end());
    
    
     //(we no longer need to fulfill a quota for each) ingredient, so just take the best overall, unless we have reached b[i] for that ingredient
     while (k > 0 && !allIngredients.empty()) {
          auto quality = allIngredients.back().first;
          int type = allIngredients.back().second;
          if (added[type] < b[type]) {
               totalQuality += quality;
               added[type]++;
               k--;
          }
          allIngredients.pop_back();
     }

     // not sure if needed:
     if (k > 0) {
          cout << -1;
          return 0;
     }

     cout << totalQuality;
     return 0;
}