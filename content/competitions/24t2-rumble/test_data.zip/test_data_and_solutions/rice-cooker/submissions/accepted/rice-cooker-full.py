A, B = map(int, input().split())

print(max(A - B, 0))
