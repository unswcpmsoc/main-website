A1, B1, C1, D1 = map(int, input().split())
A2, B2, C2, D2 = map(int, input().split())
print(min(A1//A2, B1//B2, C1//C2, D1//D2))