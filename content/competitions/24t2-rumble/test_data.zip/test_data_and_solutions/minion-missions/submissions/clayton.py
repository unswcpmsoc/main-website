a = list(map(int, input().split()))
b = list(map(int, input().split()))

c = 100_010
for i in range(4):
    c = min(int(a[i]/b[i]), c)

print(c)
