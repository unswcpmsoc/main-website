#include <stdio.h>

int main() {
    int N;
    scanf(" %d", &N);
    int e[N];

    for (int i = 0; i < N; i++) {
        scanf(" %d", &e[i]);
    }

    int count = 0;

    for (int i = 0; i < N; i++) {
        if ((i == 0 || e[i] > e[i - 1]) && (e[i] > e[i + 1] || i == N - 1)) {
            count++;
        } else if (e[i] == e[i + 1]) {
            int prev = i - 1;

            while (i < N - 1 && e[i] == e[i + 1]) {
                i++;
            }
            if ((prev < 0 || e[i] > e[prev]) && (i == N - 1 || e[i] > e[i+1])) {
                count++;
            }
        }
    }

    printf("%d\n", count);

    return 0;
}