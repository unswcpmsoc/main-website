# These lines reads the input.
N = int(input())
elevations = list(map(int, input().split()))

# For example, sum_ends stores the leftmost elevation plus the rightmost elevation.
sum_ends = elevations[0] + elevations[N-1]

# TODO: compute the answer!
answer = 0
increase = True
prev = 0
for e in elevations + [0]:
    if e > prev:
        increase = True
    if e < prev:
        if increase:
            answer += 1
        increase = False
    prev = e

# This line outputs the answer.
print(answer)