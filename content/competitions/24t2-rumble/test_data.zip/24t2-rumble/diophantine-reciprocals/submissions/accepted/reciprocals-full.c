#include <stdio.h>
typedef long long ll;

int main(void) {
    ll n; scanf("%lld", &n);

    ll ans = 1;
    for (ll i = 2; i * i <= n; i++) {
        int cnt = 0;
        while (n % i == 0) {
            n /= i;
            cnt++;
        }
        ans *= 2 * cnt + 1;
    }
    if (n > 1) {
        ans *= 3;
    }

    printf("%lld\n", ans);
}