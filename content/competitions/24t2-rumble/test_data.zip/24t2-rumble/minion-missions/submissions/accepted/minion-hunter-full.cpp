#include <bits/stdc++.h>
using namespace std;

int main() {
    int a[4], b[4], ans = 1e5;
    for (int i = 0; i < 4; i++) cin >> a[i];
    for (int i = 0; i < 4; i++) cin >> b[i];
    for (int i = 0; i < 4; i++) {
        ans = min(ans, a[i]/b[i]);
    }
    cout << ans << '\n';
}